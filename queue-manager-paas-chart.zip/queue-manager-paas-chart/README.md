# Queue Manager PaaS Helm deployment

This scaffold follows the visible structure and conventions from the supplied `sza-deployment` screenshots:
- Jenkins shared library: `jenkins-library-ocp-deployment`
- Helm dependency: `helm-paas-app-base-chart` version `1.0.0`
- A thin `templates/base-template.yaml` that includes `cfg-paas-app-base-chart.basechartconfig`
- Root-level `global.yaml`, `deployment.yaml`, `values.yaml`, and `virtualservice.yaml`
- Per-environment configuration under `values/p2/`

## Important: platform contract

The screenshots show the application-specific wrapper chart, but not the implementation or complete values schema of the internal base chart or Jenkins shared library. This is therefore a **starter scaffold**, not a verified deployable release. Validate every key against the internal chart's values schema and your PaaS onboarding documentation.

## Before using

1. Replace every `REPLACE_*` placeholder with approved onboarding values.
2. Set the internal Nexus Helm repository URL in `Chart.yaml`.
3. Confirm the actual Queue Manager container image, tag, ports, health probes, resources, startup arguments, and persistence requirements.
4. Confirm whether Queue Manager needs a broker connection, TLS certificates, credentials, or persistent storage. Add credentials only through approved Kubernetes Secret/Vault integration.
5. Confirm the `services.queue-manager` nesting and field names against `helm-paas-app-base-chart` v1.0.0. The source screenshots show similar backend/frontend fields, but do not expose the complete schema.
6. Confirm the exact `deployment.yaml` target-cluster format and traffic-control configuration with the PaaS team.
7. Keep `ambientTrafficControl` and VirtualService routing disabled until the platform team confirms the host and routing requirements.

## Repository layout

```text
queue-manager/
├── templates/
│   └── base-template.yaml
├── values/
│   └── p2/
│       ├── configmap/
│       │   └── queue-manager-config.yaml
│       ├── queue-manager-eVariables.yaml
│       ├── queue-manager-vMounts.yaml
│       ├── queue-manager-volumes.yaml
│       └── virtualservice.yaml
├── .gitignore
├── .helmignore
├── Chart.yaml
├── Jenkinsfile
├── README.md
├── deployment.yaml
├── global.yaml
├── values.yaml
└── virtualservice.yaml
```

## Validation

After configuring access to the internal chart repository:

```bash
helm dependency update .
helm lint .
helm template queue-manager .   --debug
```

`helm template` may require the base chart to be available locally and may need platform-specific values. Do not deploy until the rendered manifests and platform-specific configuration have been reviewed.

## Information still needed for a production-ready chart

- Queue Manager product/runtime and container image
- Required ports and health/readiness/liveness endpoints
- Broker or queue technology and connection requirements
- Required environment variables and secret names/keys
- CPU/memory sizing and replica/autoscaling expectations
- Persistence requirements, if any
- Ingress/VirtualService hostname and path
- Target EKS cluster, namespace, SYSID, team, and deployment branch
